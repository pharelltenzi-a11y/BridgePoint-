function getStarted() {
  alert("BridgePoint is coming alive 🚀 — stay tuned for more features!");
}
